#ifndef NUMBERINPUTLAYER_H
#define NUMBERINPUTLAYER_H

#include <gd.h>

namespace gd {

    class GDH_DLL NumberInputLayer : public FLAlertLayer {

    };

}

#endif

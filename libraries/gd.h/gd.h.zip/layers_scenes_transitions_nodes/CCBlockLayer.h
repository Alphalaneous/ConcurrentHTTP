#ifndef __CCBLOCKLAYER_H__
#define __CCBLOCKLAYER_H__

#include <gd.h>

namespace gd {
	class GDH_DLL CCBlockLayer : public cocos2d::CCLayerColor {
		protected:
			bool m_bUnknown;
			bool m_bUnknown2;
	};
}

#endif
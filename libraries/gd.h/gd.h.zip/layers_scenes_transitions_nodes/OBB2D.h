#ifndef __OBB2D_H__
#define __OBB2D_H__

#include <gd.h>

namespace gd {
    
    class OBB2D : public cocos2d::CCNode {
        // todo
    };

}

#endif

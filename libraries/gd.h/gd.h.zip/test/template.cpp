#include <iostream>
#include <gd.h>
#include <cocos2d.h>
#include <cstddef>

int main() {
// {INJECT CODE}
}
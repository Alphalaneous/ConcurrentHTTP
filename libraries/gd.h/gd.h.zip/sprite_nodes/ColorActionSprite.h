#ifndef __COLORACTIONSPRITE_H__
#define __COLORACTIONSPRITE_H__

#include <gd.h>

namespace gd {
    class GDH_DLL ColorActionSprite : public cocos2d::CCNode {

    };
}

#endif